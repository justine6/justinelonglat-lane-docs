# PowerShell Starter Pack (JTL)

This ZIP is the minimal “SDK” for the JTL Automation Toolkit API Model.

## Contents
- validate-site.mjs — validator (links/anchors/routes)
- Tag-Release.ps1 — release tag helper (freeze point)
- bust-styles.ps1 — CSS/style normalization helper (optional)
- RELEASE-CHECKLIST.md — the contract for a valid release

## Typical flow
1) Create changes
2) Validate
3) Preview locally
4) Tag a release (freeze point)
5) Deploy
6) Verify + recover if needed

Generated: 2026-02-13
