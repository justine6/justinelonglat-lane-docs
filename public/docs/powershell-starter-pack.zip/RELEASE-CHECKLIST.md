# Release Checklist (API Contract)

- [ ] Local sanity: home/README/toolkit layout consistent
- [ ] Link validation: header/footer + key routes return 200
- [ ] No 404 downloads: /docs/*.pdf and /docs/*.zip exist
- [ ] Clean diff: separate refactors from content changes
- [ ] Freeze point: create a tag (Tag-Release.ps1)
- [ ] Deploy from known-good baseline
- [ ] Post-deploy verify in incognito (theme toggle + nav + downloads)
